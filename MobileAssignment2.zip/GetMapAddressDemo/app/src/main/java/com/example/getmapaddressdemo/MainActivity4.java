package com.example.getmapaddressdemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity4 extends AppCompatActivity {

    private static final String TAG = "EditDataActivity";

    private Button btSave,btDelete,btUpdate;
    private EditText edit_item;

    DatabaseHelper DatabaseHelper;

    private String selectedAddress;
    private int selectedID;
    private int selectedLat;
    private int selectedLong;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        btSave = (Button) findViewById(R.id.btSave);
        btDelete = (Button) findViewById(R.id.btDelete);
        btUpdate = (Button) findViewById(R.id.btUpdate);
        edit_item = (EditText) findViewById(R.id.editable_item);
        DatabaseHelper = new DatabaseHelper(this);

        Intent receivedIntent = getIntent();

        selectedID = receivedIntent.getIntExtra("id",-1);

        selectedAddress = receivedIntent.getStringExtra("address");

        edit_item.setText(selectedAddress);

        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = edit_item.getText().toString();
                if(!item.equals("")){
                    DatabaseHelper.updateName(item,selectedID,selectedAddress);
                }else{
                    toastMessage("You must enter an address");
                }
            }
        });

        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String item = edit_item.getText().toString();
                if(!item.equals("")){
                    DatabaseHelper.updateName(item,selectedID,selectedAddress);
                }else{
                    toastMessage("You must enter an address");
                }
            }
        });

        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatabaseHelper.deleteName(selectedID,selectedAddress);
                edit_item.setText("");
                toastMessage("Removed from database");
            }
        });
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
