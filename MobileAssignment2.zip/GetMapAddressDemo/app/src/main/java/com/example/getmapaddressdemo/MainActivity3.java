package com.example.getmapaddressdemo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    private static final String TAG = "MainActivity3";

    DatabaseHelper DatabaseHelper;

    private ListView ListView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        ListView = (ListView) findViewById(R.id.listView);
        DatabaseHelper = new DatabaseHelper(this);

        populateListView();
    }

    private void populateListView() {
        Log.d(TAG, "populateListView: Displaying data in the ListView.");

        Cursor data = DatabaseHelper.getData();
        ArrayList<String> listData = new ArrayList<>();
        while(data.moveToNext()){
            listData.add(data.getString(1));
        }
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        ListView.setAdapter(adapter);

        ListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String address = adapterView.getItemAtPosition(i).toString();
                Log.d(TAG, "onItemClick: You Clicked on " + address);

                Cursor data = DatabaseHelper.getItemID(address);
                int id = -1;
                while(data.moveToNext()){
                    id= data.getInt(0);
                }
                if(id > -1){
                    Log.d(TAG, "onItemClick: The ID is: " + id);
                    Intent editScreenIntent = new Intent(MainActivity3.this, MainActivity4.class);
                    editScreenIntent.putExtra("id",id);
                    editScreenIntent.putExtra("address",address);
                    startActivity(editScreenIntent);
                }
                else{
                    toastMessage("No id associated with that address");
                }

                Cursor dataLat = DatabaseHelper.getItemID(address);
                int idLat = -1;
                while(dataLat.moveToNext()){
                    idLat= dataLat.getInt(0);
                }
                if(idLat> -1){
                    Log.d(TAG, "onItemClick: The ID is: " + idLat);
                    Intent editScreenIntent = new Intent(MainActivity3.this, MainActivity4.class);
                    editScreenIntent.putExtra("id",idLat);
                    editScreenIntent.putExtra("address",address);
                    startActivity(editScreenIntent);
                }
                else{
                    toastMessage("No latitude associated with that address");
                }

                Cursor dataLong = DatabaseHelper.getItemID(address);
                int idLong = -1;
                while(dataLong.moveToNext()){
                    idLong= dataLong.getInt(0);
                }
                if(idLong > -1){
                    Log.d(TAG, "onItemClick: The ID is: " + idLong);
                    Intent editScreenIntent = new Intent(MainActivity3.this, MainActivity4.class);
                    editScreenIntent.putExtra("id",idLong);
                    editScreenIntent.putExtra("address",address);
                    startActivity(editScreenIntent);
                }
                else{
                    toastMessage("No longitude associated with that address");
                }
            }
        });
    }

    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}
